import React from "react";
import { motion } from "framer-motion";

const withPageTransitions = (WrappedComponent) => {
  return (props) => {
    return (
      <motion.div
        initial={{ opacity: 0, y: -100 }} // Adjust this to control entrance direction
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 100 }} // Adjust this to control exit direction
        transition={{ duration: 0.5 }}>
        <WrappedComponent {...props} />
      </motion.div>
    );
  };
};

export default withPageTransitions;
